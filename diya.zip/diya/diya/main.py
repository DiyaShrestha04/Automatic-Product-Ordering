#DARAZ AUTOMATION
from selenium import webdriver
import os
from dotenv import load_dotenv
from selenium.webdriver.common.keys import Keys
from time import sleep

# Initializing dotenv to read from .env file
load_dotenv()

DRIVER_PATH = os.path.join(os.getcwd(), "driver", "geckodriver")

# Getting values from the .env file
LOGIN_URL = "https://member.daraz.com.np/user/login?spm=a2a0e.11779170.header.d5.71f82d2bC8iD1x&redirect=https%3A%2F%2Fwww.daraz.com.np%2F%23"
ORDER_URL = [
    "https://www.daraz.com.np/products/aluminium-alloy-metal-adjustable-laptop-stand-for-10-to-17-inches-mackbooklaptopstab-i105711486-s1027505956.html?spm=a2a0e.11779170.flashSale.4.7f672d2bYzRu6P",
    "https://www.daraz.com.np/products/usb-powered-portable-table-fan-mini-usb-desk-fan-small-quiet-personal-cooler-usd-i105613454-s1027397631.html?spm=a2a0e.11779170.flashSale.5.71f82d2by53YDC"
]

def main():
    browser = webdriver.Firefox(executable_path=DRIVER_PATH)
    browser.get(LOGIN_URL)

    # Getting username and password
    username = os.getenv("EMAIL")
    password = os.getenv("PASSWORD")

    # setting the value
    username_field = browser.find_element_by_css_selector("input[type='text']")
    username_field.send_keys(username)

    # Setting password field
    password_field = browser.find_element_by_css_selector("input[type='password']")
    password_field.send_keys(password)

    # Clicking enter to submit the form
    password_field.send_keys(Keys.ENTER)

    print("Logged in sucessfully !")

    sleep(5)
    # Opening the product URL to order the product
    for url in ORDER_URL:
        browser.get(url)

        # Clicking the order now button
        sleep(5)
        buy_now_button = browser.find_element_by_css_selector('button.add-to-cart-buy-now-btn:nth-child(2)')
        buy_now_button.click()

        sleep(2)

    browser.get('https://cart.daraz.com.np/cart')

    tick_box = browser.find_element_by_css_selector('.list-header-checkbox > input:nth-child(2)')
    tick_box.click()

    sleep(3)

    proceed_button = browser.find_element_by_css_selector('button.next-btn:nth-child(2)')
    proceed_button.click()

    print("Ordered Sucessfully !")


# Running the main function if the program is executed
if __name__ == "__main__":
    main()
