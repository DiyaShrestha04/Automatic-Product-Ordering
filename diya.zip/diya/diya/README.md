# Daraz Product Order Automation with Python

## Activating the virtual environment

### Linux / MacOS
```
source venv/bin/activate
```
### Windows
```
source venv/bin/activate.ps1
```

## Installing the dependencies
```
python -m pip install -r requirements.txt
```

## Running the program
```
python main.py
```